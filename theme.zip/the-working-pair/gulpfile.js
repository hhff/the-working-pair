require('coffee-script/register');
require('./src/config/gulpfile.coffee');